<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id4103787_oktioryan0140","billabong45","id4103787_sertifikasi") or die ("could not connect database");
?>
